package com.bennohan.myfriends.base

import com.crocodic.core.base.viewmodel.CoreViewModel

open class BaseViewModel : CoreViewModel() {
    override fun apiLogout() {
        TODO("Not yet implemented")
    }

    override fun apiRenewToken() {
        TODO("Not yet implemented")
    }
}