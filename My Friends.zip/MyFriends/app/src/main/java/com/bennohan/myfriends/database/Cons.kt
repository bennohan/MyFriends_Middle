package com.bennohan.myfriends.database

object Cons {
    object USER {
//        const val EMAIL = "email"
//        const val PASSWORD ="password"
        const val PROFILE = "login"
//        const val PHOTO = "photo"
    }
    object FRIENDS {
        const val FRIENDS = "friends"
    }
}